import React, { useState } from 'react';
import { Timer as TimerIcon, PlusCircle } from 'lucide-react';
import ProjectList from './components/ProjectList';
import TimeTracker from './components/TimeTracker';
import Stats from './components/Stats';
import { Project } from './types';

function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [isTracking, setIsTracking] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TimerIcon className="h-6 w-6 text-indigo-600" />
              <span className="text-xl font-semibold text-gray-900">TaskFlow Timer</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="btn-primary">
                <PlusCircle className="h-5 w-5 mr-2" />
                New Project
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
              <TimeTracker 
                isTracking={isTracking}
                activeProject={activeProject}
                onToggle={() => setIsTracking(!isTracking)}
              />
            </div>
            <ProjectList 
              projects={projects}
              activeProject={activeProject}
              onProjectSelect={setActiveProject}
            />
          </div>
          <div>
            <Stats projects={projects} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;