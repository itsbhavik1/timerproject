export interface Project {
  id: string;
  name: string;
  hourlyRate: number;
  totalHours: number;
  client?: string;
  description?: string;
}