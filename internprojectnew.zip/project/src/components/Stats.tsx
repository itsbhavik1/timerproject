import React from 'react';
import { BarChart3, Clock, DollarSign } from 'lucide-react';
import { Project } from '../types';

interface StatsProps {
  projects: Project[];
}

export default function Stats({ projects }: StatsProps) {
  const totalHours = projects.reduce((sum, project) => sum + project.totalHours, 0);
  const totalEarnings = projects.reduce((sum, project) => sum + (project.totalHours * project.hourlyRate), 0);
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Overview</h2>
      <div className="space-y-4">
        <div className="p-4 bg-indigo-50 rounded-lg">
          <div className="flex items-center text-indigo-600 mb-2">
            <Clock className="h-5 w-5 mr-2" />
            <span className="font-medium">Total Hours</span>
          </div>
          <div className="text-2xl font-semibold">{totalHours}h</div>
        </div>
        
        <div className="p-4 bg-green-50 rounded-lg">
          <div className="flex items-center text-green-600 mb-2">
            <DollarSign className="h-5 w-5 mr-2" />
            <span className="font-medium">Total Earnings</span>
          </div>
          <div className="text-2xl font-semibold">${totalEarnings.toFixed(2)}</div>
        </div>
        
        <div className="p-4 bg-purple-50 rounded-lg">
          <div className="flex items-center text-purple-600 mb-2">
            <BarChart3 className="h-5 w-5 mr-2" />
            <span className="font-medium">Active Projects</span>
          </div>
          <div className="text-2xl font-semibold">{projects.length}</div>
        </div>
      </div>
    </div>
  );
}