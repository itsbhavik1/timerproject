import React from 'react';
import { Project } from '../../types';
import TimerDisplay from './TimerDisplay';
import TimerControls from './TimerControls';

interface TimeTrackerProps {
  isTracking: boolean;
  activeProject: Project | null;
  onToggle: () => void;
}

export default function TimeTracker({ isTracking, activeProject, onToggle }: TimeTrackerProps) {
  return (
    <div className="text-center">
      <TimerDisplay isTracking={isTracking} />
      <TimerControls isTracking={isTracking} onToggle={onToggle} />
      {activeProject && (
        <div className="mt-4 text-gray-600">
          Currently tracking: {activeProject.name}
        </div>
      )}
    </div>
  );
}