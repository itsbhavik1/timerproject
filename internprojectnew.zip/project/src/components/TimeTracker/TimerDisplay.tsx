import React, { useState, useEffect } from 'react';
import { formatTime } from '../../utils/timeUtils';

interface TimerDisplayProps {
  isTracking: boolean;
}

export default function TimerDisplay({ isTracking }: TimerDisplayProps) {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    let interval: number | undefined;
    
    if (isTracking) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTracking]);

  return (
    <div className="text-6xl font-mono mb-4">
      {formatTime(seconds)}
    </div>
  );
}