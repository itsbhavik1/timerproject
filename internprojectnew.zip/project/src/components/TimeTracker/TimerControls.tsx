import React from 'react';
import { Play, Pause } from 'lucide-react';

interface TimerControlsProps {
  isTracking: boolean;
  onToggle: () => void;
}

export default function TimerControls({ isTracking, onToggle }: TimerControlsProps) {
  return (
    <div className="flex items-center justify-center space-x-4">
      <button
        onClick={onToggle}
        className={`rounded-full p-4 ${
          isTracking ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
        }`}
      >
        {isTracking ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
      </button>
    </div>
  );
}