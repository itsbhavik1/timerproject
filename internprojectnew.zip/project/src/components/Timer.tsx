import React, { useState, useEffect } from 'react';
import { Play, Pause } from 'lucide-react';
import { Project } from '../types';

interface TimerProps {
  isTracking: boolean;
  activeProject: Project | null;
  onToggle: () => void;
}

export default function Timer({ isTracking, activeProject, onToggle }: TimerProps) {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    let interval: number | undefined;
    
    if (isTracking) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTracking]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="text-center">
      <div className="text-6xl font-mono mb-4">{formatTime(seconds)}</div>
      <div className="flex items-center justify-center space-x-4">
        <button
          onClick={onToggle}
          className={`rounded-full p-4 ${
            isTracking ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
          }`}
        >
          {isTracking ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
        </button>
      </div>
      {activeProject && (
        <div className="mt-4 text-gray-600">
          Currently tracking: {activeProject.name}
        </div>
      )}
    </div>
  );
}