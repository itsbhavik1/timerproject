import React from 'react';
import { Clock, DollarSign } from 'lucide-react';
import { Project } from '../types';

interface ProjectListProps {
  projects: Project[];
  activeProject: Project | null;
  onProjectSelect: (project: Project) => void;
}

export default function ProjectList({ projects, activeProject, onProjectSelect }: ProjectListProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Your Projects</h2>
      <div className="space-y-4">
        {projects.map(project => (
          <div
            key={project.id}
            className={`p-4 rounded-lg border transition-colors ${
              activeProject?.id === project.id
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
            onClick={() => onProjectSelect(project)}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{project.name}</h3>
              <span className="text-sm text-gray-500">${project.hourlyRate}/hr</span>
            </div>
            <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                {project.totalHours}h
              </div>
              <div className="flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                ${(project.totalHours * project.hourlyRate).toFixed(2)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}