# TaskFlow Timer

TaskFlow Timer is a simple yet powerful time tracking and productivity tool designed specifically for freelancers and independent contractors. It helps professionals track time spent on different client projects, automatically calculate earnings, and gain insights into their productivity.

## Features

- **Project Time Tracking**: Start and stop timers for different projects
- **Real-time Earnings Calculation**: Automatically calculate earnings based on hourly rates
- **Project Management**: Create and manage multiple client projects
- **Visual Analytics**: View your productivity and earnings statistics
- **Clean, Modern Interface**: Intuitive design for effortless time tracking

## Tech Stack

- React
- TypeScript
- Tailwind CSS
- Lucide React Icons

## Getting Started

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/taskflow-timer.git
   ```

2. Install dependencies:
   ```bash
   cd taskflow-timer
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open [http://localhost:5173](http://localhost:5173) to view it in the browser.

## Screenshots

![TaskFlow Timer Interface](https://images.unsplash.com/photo-1611224923853-80b023f02d71?auto=format&fit=crop&w=1200&q=80)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.